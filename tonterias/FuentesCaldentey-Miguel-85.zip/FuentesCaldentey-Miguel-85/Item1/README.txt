En la base de datos:
El administrador1 tiene dos loots: uno en el que su publication moment es menos de un mes y otro que está entre 1 mes y dos meses. Ambas corresponden a la conferencia learn Unity.
El administrador2 tienes dos loots: ambos mayores que dos meses. Corresponden a la conferencia Criptografia(past conference)

TICKER:
El ticker está hecho correctamente y sigue el patrón al crearse. En el populate no sigue el patrón indicado, 
al subirlo al clevercloud me he dado cuenta y no me ha dado tiempo cambiarlo,
 tan solo sería cambiar en el populate.xml el atributo ticker de los 4 loot.