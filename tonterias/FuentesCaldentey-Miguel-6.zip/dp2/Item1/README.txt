BASE DE DATOS
-Company1: company1 tiene position1 que tiene audit10, el cual tiene a netcashe1 y netcashe2
-Company2: company2 tiene position2 que tiene audit11, el cual tiene a netcashe3y netcashe4
**En company1/position1 hay dos audits, las netcashes se encuentran en el audit con el título TEST

FUNCIONAMIENTO
Para llegar a las netcashes:
	-Como company: inicia sesion, navega por sus positions, se mete en las audits de esa position suyas y en la lista de las audit están sus respectivos netcashes
	-Como auditor: inicia sesion, navega por sus audits, y desde esa lista llega a las netcashes de sus audits
**Cualquier  intento de navegar a un audit que no le corresponden saltará un NO TIENE ACCESO.

TEST
El test(jUnit) sale negativo porque el actor que lo crea es un auditor y solo lo pueden crear 
las companys